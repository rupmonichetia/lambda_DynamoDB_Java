package com.Dynamodb.repository;

import com.Dynamodb.entity.PersonRequest;
public class ProductInfoRepository extends AbstractRepository<PersonRequest, String> {
}
